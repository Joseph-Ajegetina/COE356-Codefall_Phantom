# ArtisanBridge
Linking artisans to populace


Clone the repository
Create a branch on your machine where you can push your code and any changes


Backend "flask" dependencies added with core api
